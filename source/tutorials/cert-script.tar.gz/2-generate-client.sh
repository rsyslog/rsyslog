# This creates the private CA Key
certtool --generate-privkey --outfile client-key.pem --bits 2048

# This creates the cert request
certtool --generate-request --load-privkey client-key.pem --outfile request.pem --template client.cfg

# This creates the client cert
certtool --generate-certificate --load-request request.pem --outfile client-cert.pem --load-ca-certificate ca.pem --load-ca-privkey ca-key.pem --template client.cfg

# Cleanup
rm -f request.pem
